Name - Ritish Bansal
Roll No - 190101076
Email id - rbansal@iitg.ac.in

Instructions To Run code
Environment used for running is Linux g++
Command to compile file  - g++ 190101076_Assign01.cpp
Command to run code - ./a.out

Assumptions and Properties of program
Assumed input.txt is input file and it must be present in same directory as of code for running.
Three files intermediate.txt , listing.txt, output.txt will be formed.
intermediate.txt is file that is passed in between assembler.
listing.txt contain object code for each of instruction.
output.txt has final machine code output.
Also assumed that comments begin with . character.
Errors will be printed on terminal.
There are no spaces for indirect addressing and hexadecimal constants always have even length as they consume 1/2 byte.
Program uses c++ file I/O. If any error is encountered it is printed on terminal and execution stops.
Each instruction must be on different line.
