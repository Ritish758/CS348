Name - Ritish Bansal
Roll No - 190101076
Email id - rbansal@iitg.ac.in

This folder has 5 more files as input.txt, 190101076.l , lex.yy.c , output.txt, a.out

Instructions to run the code
Environment to run code is Linux g++
In command terminal execute these commands - 
     1. lex 190101076.l
     2. g++ lex.yy.c
     3. ./a.out
     
Assumptions and Properties
1. Input is present in input.txt and must present in same directory of lex file.
2. Generated output at last will be there in output.txt
3. By executing first command lex.yy.c file will be formed 
4. Then Use g++ to compile this file as code in lex file is written in C++.
5. All FILE IO related errors will be printed on terminal.
6. Assumed that there are no unknown symbols in Input.txt
7. In output all tokens and there specifiers are displayed and at last Symtab is displayed.

